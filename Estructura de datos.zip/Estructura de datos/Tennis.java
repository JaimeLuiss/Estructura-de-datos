package tallercolores;

public class jovenBaloncesto {
    private String Pantaloneta;
    private String Pelota;
    private String raqueta;
    private String deporte;

    public jovenBaloncesto(String Pantaloneta, String Pelota, String raqueta, String deporte) {
        this.Pantaloneta = Pantaloneta;
        this.Pelota = Pelota;
        this.raqueta = raqueta;
        this.deporte = deporte;
    }
    
    public String getPantaloneta() {
        return Pantaloneta;
    }

    public void setPantaloneta(String Pantaloneta) {
        this.Pantaloneta = Pantaloneta;
    }

    public String getPelota() {
        return Pelota;
    }

    public void setPelota(String Pelota) {
        this.Pelota = Pelota;
    }

    public String getraqueta() {
        return raqueta;
    }

    public void setraqueta(String raqueta) {
        this.raqueta = raqueta;
    }

    public String getdeporte() {
        return deporte;
    }

    public void setdeporte(String deporte) {
        this.deporte = deporte;
    }
    
    public void caminar() {
        System.out.println("El joven " + deporte + " esta jugando en la cancha");
    }
    
    public void saltar() {
        System.out.println("El joven " + deporte + " esta jugando tennis");
    }
    
    public void recibirpelota() {
        System.out.println("El joven " + deporte + " recibiendo la pelota");
    }
    
    public void correr() {
        System.out.println("El joven " + deporte + " esta corriendo");
    }
    
    public void juega() {
        System.out.println("El joven " + deporte + " esta jugando");
    }
}
