package imagen;

public class imegen {

    public static void main(String[] args) {
        teniis se = new teniis("Azul oscuro", "Azul claro", "Azul combinado con azul oscuro y claro", "Ramiro");
        se.recibirpelota();
        se.juega();
        se.correr();
    }
}